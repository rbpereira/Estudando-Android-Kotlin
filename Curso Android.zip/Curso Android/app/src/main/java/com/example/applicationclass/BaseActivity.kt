package com.example.applicationclass

import android.content.Intent
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.applicationclass.buttons.*
import com.example.applicationclass.google.GoogleAdViewActivity
import com.example.applicationclass.google.GoogleMapViewActivity
import com.example.applicationclass.text.*

open class BaseActivity : AppCompatActivity(){
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.activity_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        // Handle item selection
        return when (item.itemId) {
            R.id.auto_complete_text_view -> {
                val intent = Intent(this, AutoCompleteTextViewActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.checked_text_view -> {
                val intent = Intent(this, CheckedTextViewActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.date -> {
                val intent = Intent(this, DateActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.email -> {
                val intent = Intent(this, EmailActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.multi_auto_complete_text_view -> {
                val intent = Intent(this, MultiAutoCompleteTextViewActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.multiline_text -> {
                val intent = Intent(this, MultilineTextActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.number -> {
                val intent = Intent(this, NumberActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.number_decimal -> {
                val intent = Intent(this, NumberDecimalActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.number_signed -> {
                val intent = Intent(this, NumberSignedActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.password -> {
                val intent = Intent(this, PasswordActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.password_numeric -> {
                val intent = Intent(this, PasswordNumericActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.phone -> {
                val intent = Intent(this, PhoneActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.plain_text -> {
                val intent = Intent(this, PlainTextActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.postal_address -> {
                val intent = Intent(this, PostalAddressActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.text_input_layout -> {
                val intent = Intent(this, TextInputLayoutActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.text_view -> {
                val intent = Intent(this, TextViewActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.time -> {
                val intent = Intent(this, TimeActivity::class.java)
                this.startActivity(intent)
                return true
            }
            //butons
            R.id.button -> {
                val intent = Intent(this, ButtonActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.image_button -> {
                val intent = Intent(this, ImageButtonActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.chip -> {
                val intent = Intent(this, ChipActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.chip_group -> {
                val intent = Intent(this, ChipGroupActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.check_box -> {
                val intent = Intent(this, CheckBoxActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.radio_group -> {
                val intent = Intent(this, RadioGroupActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.radio_button -> {
                val intent = Intent(this, RadioButtonActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.toggle_button -> {
                val intent = Intent(this, ToggleButtonActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id._switch -> {
                val intent = Intent(this, SwitchActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.floating_action_button -> {
                val intent = Intent(this, FloatingActionButtonActivity::class.java)
                this.startActivity(intent)
                return true
            }






            R.id.ad_view -> {
                val intent = Intent(this, GoogleAdViewActivity::class.java)
                this.startActivity(intent)
                return true
            }
            R.id.map_view -> {
                val intent = Intent(this, GoogleMapViewActivity::class.java)
                this.startActivity(intent)
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}