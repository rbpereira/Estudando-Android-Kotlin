package com.example.applicationclass

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class HomeActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        this.setTitle(R.string.title_activity_main)
    }
}
