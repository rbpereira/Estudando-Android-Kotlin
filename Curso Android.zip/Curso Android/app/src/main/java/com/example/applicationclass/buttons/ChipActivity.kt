package com.example.applicationclass.buttons

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class ChipActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chip)
        this.setTitle(R.string.chip)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
