package com.example.applicationclass.buttons

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class ChipGroupActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chip_group)
        this.setTitle(R.string.chip_group)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
