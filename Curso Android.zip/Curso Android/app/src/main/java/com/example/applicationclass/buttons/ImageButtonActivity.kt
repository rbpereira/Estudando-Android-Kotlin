package com.example.applicationclass.buttons

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class ImageButtonActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_button)
        this.setTitle(R.string.image_button)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
