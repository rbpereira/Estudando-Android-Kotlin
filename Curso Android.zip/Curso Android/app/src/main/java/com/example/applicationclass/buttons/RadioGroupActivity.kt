package com.example.applicationclass.buttons

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class RadioGroupActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_radio_group)
        this.setTitle(R.string.radio_group)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
