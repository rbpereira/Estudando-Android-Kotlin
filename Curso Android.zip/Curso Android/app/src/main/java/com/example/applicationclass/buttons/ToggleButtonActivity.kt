package com.example.applicationclass.buttons

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class ToggleButtonActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_toggle_button)
        this.setTitle(R.string.toggle_button)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
