package com.example.applicationclass.google

import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class GoogleAdViewActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_google_ad_view)
        this.setTitle(R.string.google_title_activity_ad_view)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }


}
