package com.example.applicationclass.google

import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class GoogleMapViewActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_google_map_view)
        this.setTitle(R.string.google_title_map_view)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }


}
