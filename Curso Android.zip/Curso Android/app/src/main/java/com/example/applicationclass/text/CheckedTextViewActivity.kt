package com.example.applicationclass.text

import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class CheckedTextViewActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checked_text_view)
        this.setTitle(R.string.checked_text_view)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
