package com.example.applicationclass.text

import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class MultiAutoCompleteTextViewActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_multi_auto_complete_text_view)
        this.setTitle(R.string.multi_auto_complete_text_view)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
