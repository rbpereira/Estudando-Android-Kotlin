package com.example.applicationclass.text

import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class MultilineTextActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_multiline_text)
        this.setTitle(R.string.multiline_text)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
