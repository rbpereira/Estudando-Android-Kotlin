package com.example.applicationclass.text

import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class PasswordNumericActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_password_numeric)
        this.setTitle(R.string.password_numeric)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
