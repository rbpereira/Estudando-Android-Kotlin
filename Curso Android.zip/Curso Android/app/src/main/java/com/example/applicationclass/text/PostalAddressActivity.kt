package com.example.applicationclass.text

import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class PostalAddressActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_postal_address)
        this.setTitle(R.string.postal_address)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
