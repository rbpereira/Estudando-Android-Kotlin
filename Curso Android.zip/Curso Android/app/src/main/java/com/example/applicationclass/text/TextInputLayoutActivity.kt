package com.example.applicationclass.text

import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class TextInputLayoutActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_input_layout)
        this.setTitle(R.string.text_input_layout)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
