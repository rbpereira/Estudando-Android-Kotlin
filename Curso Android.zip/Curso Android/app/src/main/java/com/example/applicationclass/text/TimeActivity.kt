
package com.example.applicationclass.text

import android.os.Bundle
import com.example.applicationclass.BaseActivity
import com.example.applicationclass.R

class TimeActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_time)
        this.setTitle(R.string.time)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}
